import{af as o,ag as n}from"./mermaid.core-CAC4cZfi.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
