import{af as o,ag as n}from"./mermaid.core-D1EmPkBs.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
